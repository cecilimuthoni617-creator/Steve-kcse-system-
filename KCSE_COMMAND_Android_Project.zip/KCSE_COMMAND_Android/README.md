# KCSE COMMAND — Offline Android Project

## What is included
- Native Android wrapper with an entirely local HTML/CSS/JavaScript study app.
- Seven KCSE subjects: Mathematics, Physics, Chemistry, Geography, CRE, English and Kiswahili.
- Mission board, XP, ranks, study streaks, subject XP, KCSE countdown, study-minute targets and past-paper score log.
- Progress is stored on the device using WebView localStorage.
- No Internet permission is declared and no remote assets or services are used.

## Build an installable APK
This project source is prepared, but an APK is not included because Android SDK/Gradle build tools were not available in the creation environment.

On a computer with Android Studio installed:
1. Extract `KCSE_COMMAND_Android.zip`.
2. Open the extracted `KCSE_COMMAND_Android` folder in Android Studio.
3. Allow Android Studio to install/sync the required Gradle and Android SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build succeeds, select **Locate** in the notification. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and open it to install. Android may ask you to allow installation from that file manager.

## Notes
- `examDate` defaults to 1 November 2026 as a placeholder; set the correct date in Settings.
- Back up progress using **Export backup**. This creates a JSON backup file; import/restore is not implemented in v1.
- Clearing app data or uninstalling may erase local progress.
- This is a first version: past-paper questions themselves are not bundled; the app tracks your practice.


## Phone-only cloud build (GitHub Actions)
This project includes `.github/workflows/android-build.yml`. To build without a computer:
1. In your phone browser, create a **public** GitHub repository for this project (do not upload passwords or private files).
2. Upload the project files/folders into the repository, preserving `.github/workflows/android-build.yml` at the repository root.
3. Open the repository's **Actions** tab and run **Build KCSE COMMAND APK** (or push to `main`).
4. When the workflow succeeds, open the completed run and download the `KCSE-COMMAND-APK` artifact. GitHub may require signing in to download it.
5. Extract the artifact ZIP on your phone, tap `app-debug.apk`, and follow Android's install prompt.
This workflow is a convenience; it has not been run from this environment, so a successful APK build is not yet verified.
